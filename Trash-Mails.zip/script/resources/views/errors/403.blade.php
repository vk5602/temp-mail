@extends('layouts.errors')

@section('title', translate('Forbidden'))
@section('code', '403')
@section('message', translate('Forbidden'))
