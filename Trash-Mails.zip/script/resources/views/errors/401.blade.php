@extends('layouts.errors')

@section('title', translate('Unauthorised'))
@section('code', '401')
@section('message', translate('Unauthorised'))

