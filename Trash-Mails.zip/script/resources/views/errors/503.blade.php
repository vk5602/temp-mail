@extends('layouts.errors')

@section('title', translate('Service Unavailable'))
@section('code', '503')
@section('message', translate('Service Unavailable'))
