<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', $lang_locale)); ?>">

<head>
    <?php echo SEOMeta::generate(); ?>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" type="image/png" href="<?php echo e(asset($setdata['favicon'])); ?>" />
    <?php echo OpenGraph::generate(); ?>

    <?php echo Twitter::generate(); ?>


    <?php echo $__env->yieldContent('alternate'); ?>

    <?php echo $setdata['custom_tags']; ?>

    <!-- font awesome icons -->
    <link href="<?php echo e(asset('assets/css/font-awesome.css')); ?>" rel="stylesheet" type="text/css"  media="screen">
    <!-- bootstrap css -->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css"  media="screen">
    <!-- owl carousel css -->
    <link href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>" rel="stylesheet" type="text/css"  media="screen">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>">

    <?php if(\App\Models\Language::where('code', $lang_locale)->first()->rtl == 1): ?>
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/rtl.css')); ?>" type="text/css"  media="screen">
    <?php endif; ?>

    <!-- Custom  -->

    <?php if(!empty($setdata['google_analytics_code'])): ?>
        <!-- Google Analytics -->
        <script>
            (function(i, s, o, g, r, a, m) {
                i['GoogleAnalyticsObject'] = r;
                i[r] = i[r] || function() {
                    (i[r].q = i[r].q || []).push(arguments)
                }, i[r].l = 1 * new Date();
                a = s.createElement(o),
                    m = s.getElementsByTagName(o)[0];
                a.async = 1;
                a.src = g;
                m.parentNode.insertBefore(a, m)
            })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

            ga('create', '<?php echo e($setdata['google_analytics_code']); ?>', 'auto');
            ga('send', 'pageview');
        </script>
        <!-- End Google Analytics -->
    <?php endif; ?>


    <?php if(!empty($setdata['google_analytics_4'])): ?>
    <!-- Google Analytics -->
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo e($setdata['google_analytics_4']); ?>"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', '<?php echo e($setdata['google_analytics_4']); ?>');
    </script>
    <!-- End Google Analytics -->
    <?php endif; ?>


    <?php if(!empty($setdata['google_tag_manager'])): ?>
        <!-- Google Tag Manager -->
        <script>
            (function(w, d, s, l, i) {
                w[l] = w[l] || [];
                w[l].push({
                    'gtm.start': new Date().getTime(),
                    event: 'gtm.js'
                });
                var f = d.getElementsByTagName(s)[0],
                    j = d.createElement(s),
                    dl = l != 'dataLayer' ? '&l=' + l : '';
                j.async = true;
                j.src =
                    'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
                f.parentNode.insertBefore(j, f);
            })(window, document, 'script', 'dataLayer', '<?php echo e($setdata['google_tag_manager']); ?>');
        </script>
        <!-- End Google Tag Manager -->
    <?php endif; ?>



    <!--SET DYNAMIC VARIABLE IN STYLE-->
    <style>
        :root {
            --main-color: <?php echo e($setdata['main_color']); ?>;
            --color1: <?php echo e($setdata['secondary_color']); ?>;
        }

        <?php echo $setdata['custom_css']; ?>

    </style>

    <!-- Custom Code -->
    <?php echo $setdata['head_ad']; ?>



</head>

<body>

    <?php if(!empty($setdata['google_tag_manager'])): ?>
        <!-- Google Tag Manager (noscript) -->
        <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=<?php echo e($setdata['google_tag_manager']); ?>"
                height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
        <!-- End Google Tag Manager (noscript) -->
    <?php endif; ?>


    <?php if($setdata['enable_preloader']): ?>
    <!-- Preloader Start -->
    <div class="preloader">
        <span></span>
    </div>
    <!-- Preloader End -->
    <?php endif; ?>

    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg">
        <div class="container lang_container">
            <!--  Show this only on mobile to medium screens  -->
            <a class="navbar-brand d-lg-none" href="<?php echo e(route('home')); ?>"><img alt="<?php echo e($setdata['name']); ?>"
                    class="logo_mobile" src="<?php echo e(asset($setdata['site_logo'])); ?>"></a>
            <ul class="lang_ul d-lg-none">
                <button class="navbar-toggler lang_btn" type="button" data-toggle="collapse"
                    data-target="#navbarToggle" aria-controls="navbarToggle" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"><i class="fas fa-bars"></i></span>
                </button>
                <li class="nav-item dropdown lang">
                    <a class="lang_link" type="button" id="dropdownMenuButton" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false" href="#"><img alt="<?php echo e($lang_name); ?>"
                            src="<?php echo e(asset('assets/flags/' . $lang_locale . '.png')); ?>">
                        <span><?php echo e($lang_name); ?></span></a>
                    <div class="lang_dropdown dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton">
                        <?php $__currentLoopData = \App\Models\Language::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="dropdown-item" rel="alternate" hreflang="<?php echo e($language->code); ?>"
                                href="<?php echo e(LaravelLocalization::getLocalizedURL($language->code, null, [], true)); ?>">
                                <img alt="<?php echo e($language->code); ?>"
                                    src="<?php echo e(asset('assets/flags/' . $language->code . '.png')); ?>" class="mr-2">
                                <span class="language"><?php echo e($language->name); ?></span>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </li>
            </ul>
            <!--  Use flexbox utility classes to change how the child elements are justified  -->
            <div class="collapse navbar-collapse justify-content-between" id="navbarToggle">
                <!--   Show this only lg screens and up   -->
                <a class="navbar-brand d-none d-lg-block" href="<?php echo e(route('home')); ?>"><img alt="<?php echo e($setdata['name']); ?>"
                        class="logo" src="<?php echo e(asset($setdata['site_logo'])); ?>"></a>

                <ul class="navbar-nav">
                    <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($link->postion == 0): ?>
                            <li class="nav-item">
                                <a class="nav-link"
                                    <?php if($link->target): ?> target="_blank" rel="noreferrer" <?php endif; ?>
                                    href="<?php echo e($link->url); ?>"><?php echo $link->icon; ?> <?php echo e($link->title); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item dropdown lang d_lang_none">
                        <a class="lang_link" type="button" id="dropdownMenuButton" data-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false" href="#"><img alt="<?php echo e($lang_locale); ?>"
                                src="<?php echo e(asset('assets/flags/' . $lang_locale . '.png')); ?>">
                            <span><?php echo e($lang_name); ?></span></a>
                        <div class="lang_dropdown dropdown-menu dropdown-menu-right"
                            aria-labelledby="dropdownMenuButton">
                            <?php $__currentLoopData = \App\Models\Language::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="dropdown-item" rel="alternate" hreflang="<?php echo e($language->code); ?>"
                                    href="<?php echo e(LaravelLocalization::getLocalizedURL($language->code, null, [], true)); ?>">
                                    <img alt="<?php echo e($language->code); ?>"
                                        src="<?php echo e(asset('assets/flags/' . $language->code . '.png')); ?>" class="mr-2">
                                    <span class="language"><?php echo e($language->name); ?></span>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </li>

                </ul>
            </div>
        </div>
    </nav>

    <!-- Navbar End -->

    <?php echo $__env->yieldContent('content'); ?>


    <!-- Footer Start -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="nav">
                        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('page', $page->slug)); ?>"><?php echo e($page->title); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($setdata['enable_blog']): ?>
                            <a href="<?php echo e(route('blog')); ?>"><?php echo e(translate('Blog')); ?></a>
                        <?php endif; ?>
                        <a href="<?php echo e(route('contact')); ?>"><?php echo e(translate('Contact Us')); ?></a>

                        <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($link->postion): ?>
                                <a <?php if($link->target): ?> target="_blank" rel="noreferrer" <?php endif; ?>
                                    href="<?php echo e($link->url); ?>"><?php echo $link->icon; ?> <?php echo e($link->title); ?></a>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <p class="copyright-text">
                        <?php echo translate('Copyright'); ?>

                    </p>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer End -->

    <?php if(Cookie::has('count') && Cookie::get('count') >= 5): ?>
        <!-- Modal -->
        <div class="modal fade" id="check_bot" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel"><?php echo e(translate('Human Verification')); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form method="POST" action="<?php echo e(route('check_bot')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group check_bot text-center">
                                <?php echo NoCaptcha::renderJs(); ?>

                                <?php echo NoCaptcha::display(); ?>

                                <?php if($errors->has('g-recaptcha-response')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('g-recaptcha-response')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-1 bg_main btn-block" tabindex="4">
                                    <?php echo e(translate('Verify')); ?>

                                </button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- jquery js -->
    <script src="<?php echo e(asset('assets/js/vendor/jquery.min.js')); ?>"></script>
    <!-- popper js -->
    <script src="<?php echo e(asset('assets/js/vendor/popper.min.js')); ?>"></script>
    <!-- bootstrap js -->
    <script src="<?php echo e(asset('assets/js/vendor/bootstrap.min.js')); ?>"></script>
    <!-- OWl Carousel -->
    <script src="<?php echo e(asset('assets/js/vendor/owl.carousel.min.js')); ?>"></script>
    <!-- Clipboard -->
    <script src="<?php echo e(asset('assets/js/vendor/clipboard.min.js')); ?>"></script>
    <!-- Progress Bar -->
    <script src="<?php echo e(asset('assets/js/vendor/progress.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/vendor/jquery.nicescroll.min.js')); ?>"></script>



    <!--SET DYNAMIC VARIABLE IN SCRIPT-->
    <script>
        "use strict";
        var fetch_time = "<?php echo e($setdata['fetch_time']); ?>",
            url = "<?php echo e(route('messages')); ?>",
            color = "<?php echo e($setdata['secondary_color']); ?>",
            click_to_copy = "<?php echo e(translate('Click To Copy!')); ?>",
            copied = "<?php echo e(translate('Copied!')); ?>",
            landing = "<?php echo e(translate('landing')); ?>";


            <?php echo $setdata['custom_js']; ?>

    </script>
    <!-- main js -->
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\trashmails\script\resources\views/layouts/user.blade.php ENDPATH**/ ?>