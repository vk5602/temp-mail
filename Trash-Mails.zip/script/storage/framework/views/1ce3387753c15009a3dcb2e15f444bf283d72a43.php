<?php if($features->count() > 0): ?>
<!-- Features Section Start -->
<section class="features section-padding" data-scroll-index="1">
    <div class="container">
        <div class="row justify-content-center ">
            <div class="col-md-8">
                <div class="section-title">
                    <h2>
                        <?php
                        $f = explode(' ', translate('Awesome Features'))
                        ?>
                        <?php echo e($f[0]); ?>

                        <span><?php echo e(@$f[1] . ''. @$f[2]); ?></span>
                    </h2>
                    <p><?php echo e(translate('Features Description')); ?></p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="owl-carousel features-carousel">
                <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="features-item">
                    <div class="icon"><?php echo $feature->icon; ?></div>
                    <h3><?php echo e($feature->title); ?></h3>
                    <p><?php echo e($feature->description); ?></p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <?php if(translate('Text below features' , 'text') != "Text below features"): ?>
        <div class="row mt-5">
            <?php echo translate('Text below features' , 'text'); ?>

        </div>
        <?php endif; ?>
    </div>



</section>
<!-- Features Section End -->
<?php endif; ?>


<?php if($setdata['enable_blog'] & $popular_posts->count() != 0): ?>

<!-- Popular Posts Section Start -->
<section class="popular-posts section-padding" data-scroll-index="1">
    <div class="container">
        <div class="row justify-content-center ">
            <div class="col-md-8">
                <div class="section-title">
                    <h2>
                        <?php
                        $f = explode(' ', translate('Popular Posts'))
                        ?>
                        <?php echo e($f[0]); ?>

                        <span><?php echo e(@$f[1] . ''. @$f[2]); ?></span>
                    </h2>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $popular_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-sm-6 col-md-4">
                <div class="blog-grid">
                    <div class="blog-img">
                        <a href="<?php echo e(route('post' , $post->slug)); ?>">
                            <img loading="lazy" src="<?php echo e(asset($post->image)); ?>" title="<?php echo e($post->title); ?>"
                                alt="<?php echo e($post->title); ?>">
                        </a>
                    </div>
                    <div class="blog-info">
                        <h5><a href="<?php echo e(route('post' , $post->slug)); ?>"><?php echo e(Str::limit($post->title, 40)); ?></a></h5>
                        <p><?php echo e(Str::limit($post->description, 100)); ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php if(translate('Text below posts' , 'text') != "Text below posts"): ?>
        <div class="row mt-5">
            <?php echo translate('Text below posts' , 'text'); ?>

        </div>
        <?php endif; ?>
    </div>
</section>
<!-- Popular Posts Section End -->
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\trashmails\script\resources\views/frontend/features.blade.php ENDPATH**/ ?>