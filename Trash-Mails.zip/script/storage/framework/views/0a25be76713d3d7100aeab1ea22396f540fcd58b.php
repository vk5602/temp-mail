<?php $__env->startSection('alternate'); ?>
<link rel="alternate" hreflang="x-default" href="<?php echo e(Str::replace('/'. $lang_locale, '', url()->current())); ?>" />
<?php $__currentLoopData = \App\Models\Language::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(empty(request()->segment(2))): ?>
<link rel="alternate" hreflang="<?php echo e($lang->code); ?>"
    href="<?php echo e(Str::replace('/'. $lang_locale, '/'. $lang->code, url()->current())); ?>" />
<?php else: ?>
<link rel="alternate" hreflang="<?php echo e($lang->code); ?>"
    href="<?php echo e(Str::replace('/'. $lang_locale . '/', '/'. $lang->code . '/', url()->current())); ?>" />
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('frontend.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Messages Section Start -->
<section class="messages section-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-2 col-sm-12">
                <?php echo $setdata['left_ad']; ?>

            </div>
            <div class="col-md-8 col-sm-12 mb-3">
                <div class="card mb-3 mt-3">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-12 d_show"><?php echo e(translate('INBOX')); ?></div>
                            <div class="col-4 d_hide"><?php echo e(translate('Sender')); ?></div>
                            <div class="col-6 d_hide"><?php echo e(translate('Subject')); ?></div>
                            <div class="col-2 text-right d_hide"><?php echo e(translate('View')); ?></div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="mailbox-empty">
                            <i class="fas fa-sync-alt fa-spin"></i>
                            <h3><?php echo e(translate('Your inbox is empty')); ?></h3>
                            <p><?php echo e(translate('Waiting for incoming emails')); ?></p>
                        </div>
                        <div id="mailbox"></div>
                    </div>
                </div>
                <?php echo $setdata['bottom_ad']; ?>

            </div>
            <div class="col-md-2  col-sm-12">
                <?php echo $setdata['right_ad']; ?>

            </div>
        </div>

        <?php if(translate('Text below inbox' , 'text') != "Text below inbox"): ?>
        <div class="row mt-5">
            <?php echo translate('Text below inbox' , 'text'); ?>

        </div>
        <?php endif; ?>
    </div>
</section>
<!-- Messages Section End -->

<?php echo $__env->make('frontend.features', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\trashmails\script\resources\views/frontend/index.blade.php ENDPATH**/ ?>