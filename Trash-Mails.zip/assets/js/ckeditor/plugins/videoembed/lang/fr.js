CKEDITOR.plugins.setLang('videoembed', 'fr', {
    title: 'Insérer une vidéo',
    button: 'Vidéo intégrée',
    onlytxt: 'Uniquement les URLs de Youtube, Vimeo & Dailymotion',
    validatetxt: 'Le champ URL ne doit pas être vide!',
    input_css: 'Classe CSS personnalisée :'
});

